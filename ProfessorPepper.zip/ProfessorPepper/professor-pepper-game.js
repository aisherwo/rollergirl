//initial/root variables

//set up objects
var canvas, stage;

//text objects
var titleField;
var instructionsField;

//character game objects

//declare backgrounds

var sky, bg1, bg2, mg, fgA, fgB, front;

var professorPepper;

//game parameters
var xv = 0;
var yv = 0;
var speed = 4;
var gravity = .2;
var jumpPower = -5;

//limit movement
var leftLimit = 100;
var rightLimit = 700;
var groundLimit = 600;



//use booleans to keep track of character states
var walking = false;
var jumping = false;
var resting = true;
var maraca = false;
var atEnd = false;

var leftDown = false;
var rightDown = false;



//initialization function

function init(){
    //canvas & createjs setup
    canvas = document.getElementById("gameCanvas");
    
    stage = new createjs.Stage(canvas);
    
    //preload assets, call other setup functions.
    
   
    loadSounds () ;
    addBackground();
    addProfessorPepper();
    addFront();
    addInstructionsField();
    addTitle();
    
    //setup the "ticker" loop (essentially the game engine)
    
    //add any initial event listeners
    
    createjs.Ticker.setFPS(60);
    createjs.Ticker.addEventListener("tick", onTick);
    
    document.addEventListener("keydown",onKeyDown);
    document.addEventListener("keyup", onKeyUp);
    
    
    
}

function loadSounds () {
    //register any sounds here
    console.log("Registering Sounds...");
    
    //MAKE SURE YOU GIVE CREDIT FOR ANY SOURCE MEDIA!
    
//https://freesound.org/people/Daleonfire/sounds/376694/ lisenced under creative commons, edited in Audition by Alyson Isherwood
    createjs.Sound.registerSound("sounds/play-lazer.mp3", "play-lazer");
    //https://freesound.org/people/Mativve/sounds/414329/ lisenced under creative commons edited in Audition by Alyson Isherwood
    createjs.Sound.registerSound("sounds/walking_mixdown.mp3", "walking");
        //https://freesound.org/people/kfatehi/sounds/363921/ lisenced under creative commons
    createjs.Sound.registerSound("sounds/jump.mp3", "jump");
    
    //add event handler for load if you want to play a sound automatically
    createjs.Sound.addEventListener("fileload", onSoundLoad);
   
}
function onSoundLoad(e){
    console.log("Sound Loaded: "+e);   
}


function addBackground(){
    sky = new createjs.Bitmap("images/sky.png");
    stage.addChild(sky);
    
      bg2 = new createjs.Bitmap("images/bg2.png");
    stage.addChild(bg2);
    
      bg1 = new createjs.Bitmap("images/bg1.png");
    stage.addChild(bg1);
    
      mg = new createjs.Bitmap("images/mg.png");
    stage.addChild(mg);
    
      fgA = new createjs.Bitmap("images/fgA.png");
    stage.addChild(fgA);
    
    //use onload event to get the width of the image
    
    fgA.image.onload = function(){
        console.log("image width = "+fgA.image.width);
        fgWidth = fgA.image.width;
    }
    
    //second foreground
         fgB = new createjs.Bitmap("images/fgA.png");
    stage.addChild(fgB);
    
    bg2.y = 130;
    bg1.y =70;
    mg.y = 70;
    fgA.y=140;
    fgB.y=140
 
    
    bg2.x = -200;
    bg1.x =-100;
    mg.x = -100;
    fgA.x=-50;
    fgB.x = -50;
   
}


function addProfessorPepper(){
    console.log("Adding Professor Pepper");
    //create a new instance of the character spritesheet
    professorPepper = new ProfessorPepper();
    
    professorPepper.rest();
    
  ProfessorPepper._SpriteSheet.getAnimation("jump").next = "rest";
    
    ProfessorPepper._SpriteSheet.getAnimation("maraca").next = "rest";
    
    professorPepper.x = 300;
    professorPepper.y = 600;
    stage.addChild(professorPepper);
    
    //with easeljs spritesheets, you can determine which animations play when certain animations are done
    
    
}

function addFront(){
    front = new createjs.Bitmap("images/front.png");
    stage.addChild(front);
    
    front.x = 4000
    front.y = 100
}


function addTitle(){
    titleField = new createjs.Text("Professor Pepper's Desert Adventure", "bold 32px Helvetica", "#000000");
    titleField.x = 40;
    titleField.y = 50;
    
    stage.addChild(titleField);
}
function addInstructionsField(){
	//Create a new Text "object"!
	instructionsField = new createjs.Text("Use A & D keys to move, W to jump and S to shoot the lazer!", "bold 21px Helvetica", "#000000");

    // set text position
    instructionsField.x = 40;
    instructionsField.y = 100;
    
    //use addChild() function/method to add display objects to the stage
    stage.addChild(instructionsField);  
}

function onTick(){
    stage.update();
    
      if(leftDown && !rightDown){
        //move and flip left
        xv = -speed;
        professorPepper.scaleX = 1;
    
        if(!walking && !jumping){
            professorPepper.walk();
            createjs.Sound.stop();
            createjs.Sound.play("walking", {loop: -1});
            walking = true;
        }
        
        resting = false;
        
    } else if (rightDown && !leftDown){
        //move and flip right
        xv = speed;
        professorPepper.scaleX = -1;
        
        if(!walking && !jumping){
            professorPepper.walk();
            createjs.Sound.stop();
        createjs.Sound.play("walking", {loop: -1});
            walking = true;
        }
        
        resting = false;
        
    } else if (rightDown && leftDown){
        xv = 0;

        professorPepper.rest();
        
        //update Booleans to avoid any bugs
        walking = false;
        resting = false;
        
    } else if (!leftDown && !rightDown){
        //neither right or left...
        
        //update Booleans 
        walking = false;
        xv = 0;
      
        //console.log("resting = "+resting);
        if (!resting){
            professorPepper.rest();
            resting = true;
        }
        

    }
    
    //continually apply velocity parameters
    professorPepper.x += xv;
    professorPepper.y += yv;
    
    
    //make forground A
    
     //only move background when moving right
    
   
    
   
    
    fgA.x -= xv; 
    mg.x -= xv/1.5;
    bg1.x -= xv/15;
    bg2.x -= xv/20;
    sky.x -= xv/40;
    front.x -= xv*1.5;
    
    //stop background from moving to the left
    if (fgA.x > 0){
        fgA.x = 0;
    }
    
      if (mg.x > 0){
        mg.x = 0;
    }
      if (bg1.x > 0){
        bg1.x = 0;
    }
      if (bg2.x > 0){
        bg2.x = 0;
    }
      if (sky.x > 0){
        sky.x = 0;
    }
   
    //endless background
    
    fgB.x = fgA.x + fgWidth -2;
    //when fgB get to zero, jump fgA zero (which will push fgB to the right)
    if (fgB.x <= 0){
        fgA.x = 0;
    }
    
    if (mg.x < -14552.5){
        atEnd = true
    } 
    //continually apply gravity
    yv += gravity;
    
    
    //calculate character velocity for movement
    
    if (professorPepper.x < leftLimit){
       //if gone past limit, then push them back to the limit
        professorPepper.x = leftLimit;
    } else if (professorPepper.x > rightLimit){
        professorPepper.x = rightLimit;
        
    }
    //set ground limits
    if (professorPepper.y > groundLimit){
        professorPepper.y = groundLimit;
    }
}



function onKeyUp(e){
    console.log("Key Up!"+ e.keyCode);
    if(e.keyCode == 65){
       leftDown = false;
        createjs.Sound.stop();
        
    }else if(e.keyCode == 68){
       rightDown = false;
        createjs.Sound.stop();
    } else if (e.keyCode == 87){
        jumping = false;
        createjs.Sound.stop();
    }
}

function onKeyDown(e){
    console.log("Key Down!"+ e.keyCode);
    if(e.keyCode==68){
       rightDown = true;
        }   
    else if (e.keyCode==65){
        leftDown = true;
    }else if (e.keyCode == 87) {
     if (jumping == false){
     yv = jumpPower;
     professorPepper.jump();
    jumping = true;
         createjs.Sound.stop();
    createjs.Sound.play("jump");
    walking = false;
     }
    } else if (e.keyCode == 83){
        if (maraca == false);{
        professorPepper.maraca();
        createjs.Sound.play("play-lazer");
        
       
    }

}
}



